package frlgrd.animatededittext;

public interface OnNonKeyboardRequestListener {
	void onNonKeyboardRequested();
}